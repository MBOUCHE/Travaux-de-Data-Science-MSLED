import os
os.makedirs('Dataset/DiscoursEnAnEXP', exist_ok=True)
os.makedirs('Dataset/DiscoursEnAnEXT', exist_ok=True)
os.makedirs('Dataset/DiscoursEnAnCLEANED', exist_ok=True)
os.makedirs('Dataset/DiscoursEnSIM', exist_ok=True)
os.makedirs('Dataset/DiscoursEnAnSUMMARIZED', exist_ok=True)
os.makedirs('Dataset/PREDICTIONS', exist_ok=True)
