from os import listdir
from os.path import isfile, join

fichiers = [f for f in listdir('Dataset/DiscoursEnAnEXP') if isfile(join('Dataset/DiscoursEnAnEXP', f))]

for f in fichiers:
	txtfile='Dataset/DiscoursEnAnEXP/'+f 

	#Supprimer l'actuel fichier dans DiscoursEnLAST et mettre à jour celui-ci sans retour à la ligne pour '!'', ';', ':'
	
	file = open(txtfile, "r")

	fusion_line = ''
	del_chariot = ''
	del_mark = ''
	del_excl = ''
	del_coma = ''
	del_2p = ''

	for line in file:
		fusion_line = fusion_line + line
	for phrase in fusion_line:
		del_chariot = del_chariot+phrase.replace("\n", "")
	for w in del_chariot:
		del_mark = del_mark+w.replace(".", ".\n\n")
	for w in del_mark:
		del_excl = del_excl+w.replace("!", "!\n\n")
	for w in del_excl:
		del_2p = del_2p+w.replace(":", ":\n\n")
	for w in del_2p:
		del_coma = del_coma+w.replace(";", ";\n\n")
	
	if not isfile("Dataset/DiscoursEnAnEXT/"+f): #else remove("DiscoursEnAnEXT/"+f+".txt")
		with open("Dataset/DiscoursEnAnEXT/"+f, "w") as o:
			o.write(del_coma)
		o.close()

	file.close()
