from os import listdir
from os.path import isfile, join
from stop_words import get_stop_words
import nltk
import re

fichiers = [f for f in listdir('Dataset/DiscoursEnAnEXT') if isfile(join('Dataset/DiscoursEnAnEXT', f))]

for f in fichiers:
    file = open('Dataset/DiscoursEnAnEXT/'+f, "r")
    Counter = 0
    word_data = []
      
    Content = file.read() 
    CoList = Content.split("\n") 
      
    for i in CoList: 
        if i: 
            Counter += 1
    Counter = 2*Counter-1
    with open('Dataset/DiscoursEnAnEXT/'+f) as g:
        sentenses = g.readlines()[0:Counter]
        for i in range(Counter):
            if re.sub(r'[^\w\s\n]','',sentenses[i]) != []:
                sentense = nltk.word_tokenize( re.sub(r'[^\w\s\n]','',sentenses[i]))
                tokens = [word for word in sentense if word not in get_stop_words('english')]
                word_data.append(tokens)

    if not isfile("Dataset/DiscoursEnAnCLEANED/"+f): #else remove("DiscoursEnAnEXT/"+f+".txt")
        with open("Dataset/DiscoursEnAnCLEANED/"+f, "w") as o:
            for tokens in word_data:
                sent = ' '.join(tokens)
                o.write(sent+'\n')
            o.close()
    file.close()
