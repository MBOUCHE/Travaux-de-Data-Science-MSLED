#install pymupdf using pip install pymupdf 
import fitz

from os import listdir, remove
from os.path import isfile, join

fichiers = [f for f in listdir('Dataset/DiscoursEnAn') if isfile(join('Dataset/DiscoursEnAn', f))]

for f in fichiers:
	pdffile='Dataset/DiscoursEnAn/'+f 
	if not isfile("Dataset/DiscoursEnAnEXP/"+f+".txt"): #else remove("DiscoursEnAnEXP/"+f+".txt")
		with fitz.open(pdffile) as doc: 
			for page in doc: 
				txt = page.get_text() 
				#Supprimer l'actuel fichier dans DiscoursEnLAST et mettre à jour celui-ci
				with open("Dataset/DiscoursEnAnEXP/"+f+".txt", "a") as o:
					o.write(txt)

				with open("Dataset/DiscoursEnLAST/"+f+".txt", "a") as o:
					o.write(txt)


